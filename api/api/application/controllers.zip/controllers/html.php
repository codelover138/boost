<?php

class Html extends CI_Controller
{
    public function index()
    {
        $this->load->view('html');
    }
}