<?php

class Cl_test extends CI_Controller
{
    public function index()
    {
        $this->load->view('cl_test');
    }
}