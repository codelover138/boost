<!DOCTYPE html>
<html lang="en">
<head>

    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="SKYPE_TOOLBAR" content="SKYPE_TOOLBAR_PARSER_COMPATIBLE" />

    <!--JQuery-->
    <script src="<?php echo base_url(); ?>resources/js/jquery-2.1.3.min.js"></script>

    <!--Bootstrap-->
    <link rel="stylesheet" href="<?php echo base_url(); ?>resources/bootstrap/css/bootstrap.min.css">
    <script src="<?php echo base_url(); ?>resources/bootstrap/js/bootstrap.min.js"></script>

    <link rel="stylesheet" href="<?php echo base_url(); ?>resources/css/style.css">

    <title><?php echo $page_title; ?></title>

</head>
<body>
<!--
<div class="navbar navbar-inverse navbar-fixed-top">
    <div class="container">
        <div class="navbar-header">
            <a class="navbar-brand" href="">LRMG</a>
        </div>


    </div>
</div>
-->