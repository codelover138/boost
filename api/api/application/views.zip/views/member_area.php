<div class="container top-content">
    <h1>Member Area</h1>
</div>