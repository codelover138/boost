<pre class='xdebug-var-dump' dir='ltr'><small>int</small> <font color='#4e9a06'>2000</font>
</pre><pre class='xdebug-var-dump' dir='ltr'><small>float</small> <font color='#f57900'>-1000</font>

</pre><pre class='xdebug-var-dump' dir='ltr'>
<b>array</b> <i>(size=4)</i>
  'bool' <font color='#888a85'>=&gt;</font> <small>boolean</small> <font color='#75507b'>true</font>

  'validation_results' <font color='#888a85'>=&gt;</font> 
    <b>array</b> <i>(size=1)</i>
      'organisation_id' <font color='#888a85'>=&gt;</font> <small>string</small> <font color='#cc0000'
        >'unknown field'</font> <i>(length=13)</i>
  'record_id' <font color='#888a85'>=&gt;</font> <small>int</small> <font color='#4e9a06'>67</font>
  'message' <font color='#888a85'>=&gt;</font> 
    <b>array</b> <i>(size=1)</i>
      0 <font color='#888a85'>=&gt;</font> <small>string</small> <font color='#cc0000'>'credit successfully
        created'</font> <i>(length=27)</i>
</pre>